import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def LDA(X0, X1):

    mean0 = np.mean(X0, axis=0, keepdims=True)## axis=0，计算每一列的均值
    mean1 = np.mean(X1, axis=0, keepdims=True)
    Sw = (X0-mean0).T.dot(X0-mean0) + (X1-mean1).T.dot(X1-mean1)#归一化处理
    omega = np.linalg.inv(Sw).dot((mean0-mean1).T)#对逆矩阵
    return omega

if __name__=="__main__":
    #读取csv数据
    work_book = pd.read_csv("../data/watermelon_3.5.csv", header=None)
    positive_data = work_book.values[work_book.values[:, -1] == 1.0, :]
    negative_data = work_book.values[work_book.values[:, -1] == 0.0, :]
    print (positive_data)

    #LDA
    omega = LDA(negative_data[:, 1:-1], positive_data[:, 1:-1])

    #plot
    plt.plot(positive_data[:, 1], positive_data[:, 2], "bo")
    plt.plot(negative_data[:, 1], negative_data[:, 2], "r+")
    lda_left = 0
    lda_right = -(omega[0]*0.9) / omega[1]
    plt.plot([0, 0.9], [lda_left, lda_right], 'g-')

    plt.xlabel('density')
    plt.ylabel('sugar rate')
    plt.title("3.5-LDA—Jwg20184350222")
    plt.show()